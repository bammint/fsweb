package com.example.firstproject.service;

import com.example.firstproject.dto.ArticleForm;
import com.example.firstproject.entity.Article;
import com.example.firstproject.repository.ArticleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ArticleService {
    private final ArticleRepository articleRepository;

    public List<Article> index(){
        return articleRepository.findAll();
    }

    // 단건 조회
    public Article show(Long id) {
        return articleRepository.findById(id).orElse(null);
    }

    public Article create(ArticleForm dto) {
        Article article = dto.toEntity();
        if (article.getId() != null){
            return null;
        } // 기존 데이터 수정 방지
        return articleRepository.save(article);
    }

    public Article update(Long id, ArticleForm dto) {
        // 1. dto -> entity
        Article article = dto.toEntity();
        log.info("id: {}, article: {}", id, article.toString());
        // 2. 타겟을 조회
        Article target = articleRepository.findById(id).orElse(null);
        // 3. 잘못된 요청처리
        if(target == null || id != article.getId()){
            // 400 , 잘못된 요청 응답
            log.info("잘못된 요청! id: {}, article: {}", id, article.toString());
            return null;
        }
        // 4. 업데이트
        // article은 폼에서 작성한 수정 데이터
        // target은 원본 데이터(DB에서 꺼내온 데이터)
        target.patch(article);
        Article updated = articleRepository.save(target);

        return updated;
    }
    // content

    public Article delete(Long id) {
        // 대상찾기
        Article target = articleRepository.findById(id).orElse(null);
        // 잘못된 요청 처리
        if(target == null){
            return null;
        }
        // 데이터 삭제 및 반환
        articleRepository.delete(target);
        return target;
    }
}
