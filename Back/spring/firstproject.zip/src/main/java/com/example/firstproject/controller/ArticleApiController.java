package com.example.firstproject.controller;

import com.example.firstproject.dto.ArticleForm;
import com.example.firstproject.entity.Article;
import com.example.firstproject.repository.ArticleRepository;
import com.example.firstproject.service.ArticleService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor
public class ArticleApiController {
    //    private final ArticleRepository articleRepository;
    private final ArticleService articleService;

//    @Autowired
//    public ArticleApiController(ArticleService articleService) {
//        this.articleService = articleService;
//    } => @equiredArgsConstructor 가 대체
    // @Autowired
    // private ArticleService articleService; => 필드 주입 방식



    // Get
    // 게시글 페이지(메인 페이지)
    @GetMapping("/api/articles")
    public List<Article> index(){
        return articleService.index();
    }

    // 게시글 상세 페이지(단건 조회)
    @GetMapping("/api/articles/{id}")
    public Article show(@PathVariable Long id){
        return articleService.show(id);
    }

    // post(게시글 추가)
    @PostMapping("/api/articles")
    public ResponseEntity<Article> create(@RequestBody ArticleForm dto){
        Article created = articleService.create(dto);
        return (created != null)?
                ResponseEntity.status(HttpStatus.OK).body(created) :
                ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }
    // @RequestBody -> Json 데이터 받기

    // Patch(update- 게시글 수정)
    @PatchMapping("/api/articles/{id}")
    public ResponseEntity<Article> update(@PathVariable Long id,@RequestBody ArticleForm dto){
        // 수정할 id -> id
        // form에서 수정한 데이터
        Article updated = articleService.update(id,dto);
        return (updated != null)?
                ResponseEntity.status(HttpStatus.OK).body(updated):
                ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }
    // ResponseEntity<Article>
    // Article을 담아서 ResponseEntity로 리턴 값을 보내야 한다
    // 응답 코드를 반환 할 수 있다
    // ResponseEntity에 Article이 담겨서 Json으로 반환
    // 상태코드 200 json에 내용이 같이 반환

    // delete
    @DeleteMapping("/api/articles/{id}")
    public ResponseEntity<Article> delete(@PathVariable Long id){
        Article deleted = articleService.delete(id);
        return (deleted != null)?
                ResponseEntity.status(HttpStatus.NO_CONTENT).build():
                ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }
    // ResponseEntity.status(HttpStatus.NO_CONTENT) - 204 no_content
    // 요청이 성공적으로 처리 되었음을 알린다 또한 응답 본문에는 데이터가 반환되지 않는다

}
//controller -> repository
//        controller -> service -> repository
//        전에는
//        controller 에서 repository (di)를 해주었음
//        controller 에서 service (di)를 해주고
//        service에서는 repository가 필요하므로 (di)
//        controller
//        controller => view(뷰)와 연결
//
//        RestController
//        Json(데이터)을 반환하는 RestAPI Controller이다
//        RestController
//        get,post(생성),patch(update),delete
