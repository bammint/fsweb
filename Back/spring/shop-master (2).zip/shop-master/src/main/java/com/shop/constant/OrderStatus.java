package com.shop.constant;

public enum OrderStatus {
    ORDER, CANCEL
}