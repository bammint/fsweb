package teamproject.skycode.ticket;//package teamproject.skycode.ticket;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface UserTicketRepository extends JpaRepository<UserTicket, Long> {
//}
