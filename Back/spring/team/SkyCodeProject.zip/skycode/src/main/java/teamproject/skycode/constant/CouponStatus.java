package teamproject.skycode.constant;

public enum CouponStatus {
    ONGOING, END
}
