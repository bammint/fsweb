package teamproject.skycode.ticket;//package teamproject.skycode.ticket;
//
//import lombok.Generated;
//import lombok.Getter;
//import lombok.Setter;
//
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//
//@Entity
//@Getter
//@Setter
//public class UserTicket {
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
////    가는 편
//    private String goingStart;
//    private String goingArrive;
//    private String goingDateTime;
//    private int goingPrice;
////    오는 편
//    private String comingStart;
//    private String comingArrive;
//    private String comingDateTime;
//    private int comingPrice;
//    private String grade;
//}
