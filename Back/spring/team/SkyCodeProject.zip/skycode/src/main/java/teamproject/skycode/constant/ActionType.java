package teamproject.skycode.constant;

public enum ActionType {
    EARNED, // 포인트 지급
    USED   // 포인트 사용
}
