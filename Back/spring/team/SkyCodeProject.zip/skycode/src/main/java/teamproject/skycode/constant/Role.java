package teamproject.skycode.constant;

public enum Role {
    USER, ADMIN, PUBLIC
}
