$(function () {
    $(document).ready(function() {
        $(".nyFamily").click(function() {
            $(".nyFamily ul").toggleClass("opacity");
            //   console.log(opacity);
            $(".nyFamilyIcon").toggleClass("rotate");
        });
    });
});