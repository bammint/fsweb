package com.example.member.reserv;

public enum ReservStatus {

    RESERVED, AVAILABLE
    // 예약중, 사용 가능

}