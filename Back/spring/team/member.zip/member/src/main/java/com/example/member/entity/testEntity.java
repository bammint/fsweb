package com.example.member.entity;

public class testEntity {
//     메인 업로드 테스트
}
