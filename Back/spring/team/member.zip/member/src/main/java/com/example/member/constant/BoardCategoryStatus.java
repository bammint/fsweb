package com.example.member.constant;

public enum BoardCategoryStatus {

    NOTICE, FREE

}
