package com.example.member.reservItem;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservItemRepository extends JpaRepository<ReservItem, Long> {
}
