package ch13.sec02.exam02;

public interface Rentable<P> {
	P rent();
}