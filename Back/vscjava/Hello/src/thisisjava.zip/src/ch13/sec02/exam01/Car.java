package ch13.sec02.exam01;

public class Car {
}