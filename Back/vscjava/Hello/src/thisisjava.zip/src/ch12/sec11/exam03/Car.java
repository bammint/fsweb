package ch12.sec11.exam03;

public class Car {
}