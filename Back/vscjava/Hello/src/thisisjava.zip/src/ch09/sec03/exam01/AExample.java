package ch09.sec03.exam01;

public class AExample {
	public static void main(String[] args) {
		//B 객체 생성
		A.B b = new A.B();
	}
}