package ch09.sec04.exam02;

public class AExample {
	public static void main(String[] args) {
		//A 객체 생성
		A a = new A();

		//A 메소드 호출
		a.useB();
	}
}