package ch01.sec11;
/**
 * @author 신용권
 */
/*
장제목: 1장 자바 시작하기
작성일: 2022.08.24
*/
public class Hello {
	//프로그램 실행 진입점
	public static void main(String[] args) {
		//콘솔에 출력하는 실행문
		System.out.println("Hello, Java");
	} 
} 