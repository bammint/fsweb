package ch06.sec03;

public class SportsCar {
}

class Tire {
}