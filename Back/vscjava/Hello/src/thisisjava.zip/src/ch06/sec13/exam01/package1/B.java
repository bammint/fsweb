package ch06.sec13.exam01.package1;
	
public class B {
	//필드 선언
	A a; 	//o
}