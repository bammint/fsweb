package ch06.sec13.exam01.package1;

class A {
}