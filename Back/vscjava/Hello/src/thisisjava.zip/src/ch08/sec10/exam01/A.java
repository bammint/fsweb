package ch08.sec10.exam01;

public interface A {
}