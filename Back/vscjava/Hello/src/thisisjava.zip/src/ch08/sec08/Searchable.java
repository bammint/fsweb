package ch08.sec08;

public interface Searchable {
	//추상 메소드
	void search(String url);
}