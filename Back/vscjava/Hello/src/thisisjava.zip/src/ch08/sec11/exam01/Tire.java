package ch08.sec11.exam01;

public interface Tire {
	//추상 메소드
	void roll();
}